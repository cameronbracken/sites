
  #       This program generates 250 simulations from each of the selected models
  #       Also at the end, generates post processed 250 simulations
  #       pp stands for PostProcessed;
  #The process goes:
  #              1.Generate nsims predictions from each of the nummodels models
  #              2.Draw nsims values from all nummodels models based on weighted GCV criteria
  #              3.Evaluate the skill based on the RPSS value

  #	First few lines of code are important as it reads the predictors and predictands
  #	Varaibles [nummodels,years,nsims, and year range in the for loop] needs to be changed
  #	Also FlowSeason, PredSeason needs to be changed  
  #	'modified-gcv-sel-pred.txt' is stores information of the predictors
  #
  #Variable list:
  #AllPredictors        =entire set of all possible predictors
  #FlowSeason           =character:the season of flow being predicted (used to nameoutput file)
  #PredSeason           =character:the season to be predicted (used to name output file)
  #nummodels            =number of the best models to pick from best model selection
  #nsims       =number of simulations to carry out 
  #years                =range of years to predict
  #positions            =positions of the years (first year corresponds to 1) 
  #selpredsetcombos     =ends up only holding predictor combinations
  #selgcv               =holds only gcv values from each model
  #simdata              =all simulations generated from all models before GCV weighted selection
  #simdatapp            =simulation data post processed
  #                      values sampled from all models based on GCV weights length=nsims
  #selpredset           =set of predictors 
  #model                =actual predictor values from particular set
  #calibyears           =all years except year to be predicted 
  #simyear              =year to be predicted
  #calibflows           =all flows except from year to be predicted (calibration years)
  #predmodel            =predictor values except year to simulate/predict
  #simmodel             =predictor values from year to predict
  #nyc                  =number of years in calibration period
  #np                   =number of predictors in particular model
  #nsims0,1             =indicies for begining and ending of chosen model
  #predflows            =predicted flows from a call to semiparsim
  #W                    =In this program holds model gcv based weights 
  #rannum               =is a uniform random number
  #xyzran               =rannum stuck on the front of W
  #rankW                =the first entry rankW[1] is the model randomly chosen
  #mmn                  =the position in simdata of the model prediction chosen
  #mmnp                 =percent usage of each model

  library(locfit)
  rm(list=ls())

  source('functions/myboxplot.r')
  source('functions/myboxplot-stats.r')
  source("functions/RPSS_function.r")
  source("functions/predict.r")
  source("functions/rpssplot.r")
  #source("functions/rpssplot")


  #-------edit this part (between dashes) for a specific set of predictors------------
  #filename="lees_ferry.txt"                      #output file
  f=matrix(scan("inputfiles/allpredictors.prn"),ncol=21,byrow=T)#input file
  novp=f[,2:6]                               #predictors for Nov1
  janp=f[,2:10]                              #predictors for Jan1 
  febp=cbind(f[,2:14],f[,19])                #predictors for Feb1
  aprp=cbind(f[,2:10],f[,15:21])             #predictors for Apr1 #aprp=f[,2:17] for formatlab.prn
  flows=f[,1]                                #seasonal average flows (response variable)
  
  nsims=250
  years=1949:2005

	PredSeason='apr'
  
  back=F      #use back data only, realistic prediction scenario
  dry=F       #leave bottom 10% of flow years out of prediction
  wet=F       #leave top 10% of flow years out of prediction
  rpssplot=T  #loop through the prediction model using drop validation and producec boxplot
  
  nscores=1  #do not change
  if(rpssplot){nscores=500;amount=7}

  if(PredSeason=='nov'){
    AllPredictors=novp
    nummodels=2 #2
    selpredsetcombos=matrix(scan("inputfiles/novmodels.txt",nlines=nummodels),nrow=nummodels,byrow=T)
  }
  if(PredSeason=='jan'){
    AllPredictors=janp
    nummodels=2 #2
    selpredsetcombos=matrix(scan("inputfiles/janmodels.txt",nlines=nummodels),nrow=nummodels,byrow=T)
  }
  if(PredSeason=='feb'){
    AllPredictors=febp
    nummodels=3 #2
    selpredsetcombos=matrix(scan("inputfiles/febmodels.txt",nlines=nummodels),nrow=nummodels,byrow=T)
  }
  if(PredSeason=='apr'){
    AllPredictors=aprp
    nummodels=1 #1
    selpredsetcombos=matrix(scan("inputfiles/aprmodels.txt",nlines=nummodels),nrow=nummodels,byrow=T)
  }
  
  #-----------------------------------------------------------------------------------
  
  #next 2 lines only used for taking out years, do not change
  if(dry){years=years[flows>max(flows[order(flows)[1:6]])]}
  if(wet){years=years[flows<min(flows[order(flows)[(length(flows)-5):length(flows)]])]} 

	positions=1:length(years)
  
	selpredsetcombos=data.frame(selpredsetcombos)
  selgcv=selpredsetcombos[,(ncol(selpredsetcombos)-3)]              # Takes only GCV information from file
  selpredsetcombos=selpredsetcombos[,2:(ncol(selpredsetcombos)-4)]   # Grabs only predictors information from file]
  
	if(!rpssplot){
    simdata=array(0,c((nsims*nummodels),max(years)-min(years)+1))
             #set up array for all simulations of all models for one year
	  simdatapp=array(0,c((nsims),max(years)-min(years)+1))
             #array for final nsims sims for each year 
  }
  if(rpssplot){
    simdata=matrix(0,ncol=(amount*nscores),nrow=nsims*nummodels)
	  simdatapp=matrix(0,ncol=(amount*nscores),nrow=nsims)
    rpss=vector(nscores,mode='numeric')
    dropyears=matrix(0,ncol=amount,nrow=nscores)
  }
  
	for(k in 1:nscores){
    #this loop for producting boxplot of rpss by droping 10-15% values out 
    #and predictiong them   
    
    #randomly take out 10-15% of years
    if(rpssplot){
      #round(runif(1,.10,.15)*length(years))
      dropyears[k,]=sort(sample(years,amount))
      drop=vector(length(years),mode='logical')
      for(i in 1:length(years)){
        for(j in 1:amount){
          if(years[i]==dropyears[k,j]){drop[i]=TRUE}
        }
      }
    }
    
  
    for(i in 1:nrow(selpredsetcombos) ){
        #this loop goes through all the chosen models
      selpredset=as.logical(selpredsetcombos[i,])    #pull out combination for this iteration
      model=data.frame(AllPredictors[,selpredset])  #pull out predictors corresponding to this combo
      A=AllPredictors
      
      #------important! this next lines are for taking out some years----
      if(dry){      #take out dry years
        A=AllPredictors[flows>max(flows[order(flows)[1:6]]),] 
        model=AllPredictors[flows>max(flows[order(flows)[1:6]]),selpredset]
      }        
      if(wet){
        A=AllPredictors[flows<min(flows[order(flows)[(length(flows)-5):length(flows)]]),]#take out wet years
        model=AllPredictors[flows<min(flows[order(flows)[(length(flows)-5):length(flows)]]),selpredset] #take out wet years
      }
      #-------------------------------------------
      
      if(!rpssplot){print(paste("Comibination--",i,sep=""))}
      if(!rpssplot){print(as.integer(selpredset))}
      
      if(back){ind=42}#1990 corresponds to the 42nd year 
      if(!back){ind=1}
      if(rpssplot){ind=length(years)}
      
      for( j in ind:length(years)){
      
        #for each of the chosen models this loop generates 250 predictions
        if(!back){calibyears=positions[years!=years[j]]}  #positions of calibration years
        if(back){calibyears=positions[years<years[j]]}    #only back predictions
        simyear=positions[years==years[j]]
        if(rpssplot){
          calibyears=positions[!drop]
          simyear=positions[drop]
        }
        if(!back & !rpssplot){simyear=positions[years==years[j]]}     #position of year to predict 

        #the following is specific to this program
        #PCA on just the swe data to determine the leading PC 
        #in mar and apr in case they are used 
        #I am assuming that two swe predictors will not be chosen for one model
        if(PredSeason=="apr" & !rpssplot){print(paste('PCA',j))}
        if(PredSeason=="apr"){
          if(selpredset[15]|selpredset[16]){
            swe=A[,14:16]
            marpc=prcomp(swe[,1:2])
            aprpc=prcomp(swe)
            if(selpredset[15]){
              model[,ncol(model)]=t(t(marpc$rotation[,1])%*%t(swe[,1:2]))
            }
            if(selpredset[16]){
              model[,ncol(model)]=t(t(aprpc$rotation[,1])%*%t(swe))
            }
          }
        }
        calibflows=flows[calibyears]              #flows of calibration years
        predmodel=model[calibyears,]  #subset w/o year to simulate/predict
        simmodel=model[simyear,]      #predictor values from year to predict
        
        nyc=nrow(predmodel)	    # Number of Years of Calibration period
        np=ncol(predmodel)  		# Number of Predictors
        if(rpssplot){nyp=amount}      # number of years to predict
        if(!rpssplot){nyp=1}
        
        #the following is specific to this program-dang
      
    
        #for this particular model semiparsim will call will generate nsims
        #predictions of the flow 
        predflows=predict(predmodel,simmodel,calibflows,np,nyc,nyp,nsims)
        
        #these counters keep track of the rows which contain the multimodel
        nsims0=nsims*(i-1)+1
        nsims1=nsims*i
        #these counters keep track of the columns for the drop valudation
        if(rpssplot){
          cola=amount*(k-1)+1
          colb=amount*k
        }
        
        if(!rpssplot){print(paste(nsims0,nsims1,years[j],sep=" "))}
        if(rpssplot & i==nummodels){print(paste('Ensemble model simulation ',k,'/',nscores,sep=""))}

        #each set of nsims predictions is stored end to end in one column of
        #sim data with each column corresponding to a year 
        if(!rpssplot){simdata[(nsims0:nsims1),simyear]=predflows}
        if(rpssplot){simdata[(nsims0:nsims1),cola:colb]=predflows}

      }
    } 
    
    #-----Previously separate program called GCVWeights.r 
    #Compute weights for multi-model ensembles
    W=1/selgcv	    # Least GCV combination gets more weight
    #print("GCV Weights")
    #print(W)
    W=W/sum(W)
    W=cumsum(W)
    if(!rpssplot){print("CDF of Weights")}
    if(!rpssplot){print(W)}
    mmn=1:250	# Stores selected multimodel number

    for(i in 1:nsims){
      #this loop does three things:
      # 1.determine which model is randomly selected 
      # 2.determine which prediction form that model is chosen
      # 3.stores the randomly chosen prediction in simdatapp and 
      #   the model number in mnn
      
      #1.
      rannum=runif(1,0,1) #draw a U(0,1) RV
      xyzran=c(rannum,W)	#attaches randomnumber to the weight function
      rankW=rank(xyzran)	#Assigns ranks to the above vector
                          
      #2.
      # rankW[1] gives the number of ensemble combination
      nsims0=nsims*(rankW[1]-1)+1
      nsims1=nsims*rankW[1]
      rannum=runif(1,nsims0,nsims1)
      
      #3.
      mmn[i]=round(rannum)
      simdatapp[i,]=simdata[round(rannum),]
    }
    
    mmnp=1:nrow(selpredsetcombos)	#multi model number percentage usage 
    for(i in 1:length(mmnp)){
      #estimates contribution of multimodels as percentage
      nsims0=nsims*(i-1)+1
      nsims1=nsims*i
      mmnd=mmn[(mmn<=nsims1)]
      mmnp[i]=length(mmnd[mmnd >=nsims0])
    }
    if(!rpssplot){print("percent selected from each model")}
    if(!rpssplot){print(mmnp*100/nsims)}
    if(!rpssplot){print("Order of the multimodels")}
    if(!rpssplot){print(order(mmnp*100/nsims,decreasing=TRUE))}

    if(back){RPSS(t(flows[42:57]),simdatapp[,42:57],alt=T,altobs=flows[1:41])}
    if(!back&!rpssplot){RPSS(t(flows),simdatapp[,])}
    if(rpssplot){rpss[k]=RPSS(flows[drop],simdatapp[,cola:colb])}
  }
  
  #call the function to disag the drop 10 predictions
  if(rpssplot){allrpss=rpssplotfunction(rpss,simdatapp,years,dropyears,amount,nscores,nsims,PredSeason)}

  if(!rpssplot){write(t(simdatapp[,]),file=paste(PredSeason,"ppSims.txt",sep=""),
                ncol=ncol(simdatapp[,]),sep="   ")}
  if(rpssplot){write(t(allrpss),file=paste('drop12data_',PredSeason,'.txt',sep=''),sep='   ')}
  
  if(rpssplot){print(paste('output file is drop12data_',PredSeason,'.txt',sep=''))}
  if(!rpssplot){print(paste('output file is ',PredSeason,'ppsims.txt',sep=''))}
