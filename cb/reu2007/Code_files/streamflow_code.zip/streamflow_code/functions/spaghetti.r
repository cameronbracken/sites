spaghetti=function(plt=T,years,data,histsitedata,nsims,noodles,title){
  #this function makes a spagehtti plot (a bunch of PDF's all on top of eachother)
  #all colored in light grey with a single thick black PDF on top representing 
  #the historical(obs) data
  #note:requires the package sm
  #
  #Variable list:
  #
  #inputs-
  #plt            =if plt=F then this function does nothing
  #years          =the years of the historical data, length(years) is really  
  #                just the number of columns in in data
  #data           =a data matrix with each row corresponding to a PDF  
  #                to be plotted nrow(data)=nsims, ncol(data)=nsims
  #histsitedata   =a vector or matrix with one column corresponding to 
  #                a data vector that will be plotted over all other PDFs in bold
  #                intended to be a vector of historical values
  #nsims          =number of simulations (really not needed but im not taking it out)
  #noodles        =the number of rows of data to be plotted if noodles=nsims then all 
  #                rows will be plotted
  #title          =the title of the plot that is produced
  #
  #local vaiables=
  #delta          =distance between plotting values
  #xeval          =vector of values at which to estimate the PDF
  #s              =is the output object from the calls to sm.density
  
  if(plt){
    library(sm)
    quartz()    #open a new plotting window (may only work in mac)
    l=length(years)
    
    min=min(data)
    max=max(data)
    delta=(max-min)/97
    min=min-delta
    max=max+delta
    xeval=seq(min,max,delta)
    
    s=sm.density(histsitedata,display='none',eval.points=xeval)
    s=sm.density(histsitedata,eval.points=xeval,lty=2,
        xlab='flow(cms)',ylab='Probability Density',xlim=c(0,max),
        ylim=c(0,2.3*max(s$estimate)),col='grey')
    title(main=title)
    
    for(i in 1:noodles){
    
        s=sm.density(data[i,],display='none',eval.points=xeval)
        lines(xeval,s$estimate,col='grey')
    }
    
    s=sm.density(histsitedata,display='none',eval.points=xeval)
    lines(xeval,s$estimate,lwd=2,main=title)
  }
}