  
  gs=function(d){
    #This function calculates the rotation matrix R  for a d dimensional 
    #system of the form Y=RX using Gram Schmidt Orthonormalizaton
    #
    #rm(E,I,i,j,k,sum,e)
    E=matrix(0,nrow=d,ncol=d)
 
    #make an identity matrix
    I=diag(1,d,d)
  
    #make one perpindicular verctor in last row of E 
    E[d,]=rep(1/sqrt(d),each=d)

    #orthonomalization (calculate projection of basis on new coordinate system)
    for(j in (d-1):1){
  	    sum=rep(0,each=d)
  	    for(k in (j+1):d){
  	  	    #projections
		    sum=sum+(E[k,]%*%I[j,])*E[k,]
	    }
	    E[j,]=I[j,]-sum
	    e=0
	    #normalize new row
	    e=sqrt(sum(E[j,]^2))
	    E[j,]=E[j,]/e
    }
    #print(E)
    gs=E
  }