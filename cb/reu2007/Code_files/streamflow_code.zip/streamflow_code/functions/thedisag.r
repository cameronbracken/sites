thedisag=function(years,histdata,preds,d,back=F,warning=F,maxit=100,nsims=250){
 
  #Variable list:
  #
  #histdata      =program specific, recorded monthly flows at lees ferry apr-jul
  #indexhist     =historical flow values at the index site(sum of four sites)
  #X             =disag data, years across cols, months down rows
  #years         =years in which predictions were made
  #nsims         =number of rows in ensemble prediction data
  #preds         =predictions of seasonal flow for each year, 
  #               years across cols, sims down rows
  #gs            =(function) calculates Gram Schmidt orthonormal matrix 
  #R             =rotation matrix a.k.a. Gram Schmidt orthonormal matrix
  #Y             =rotated data last row is sum(monthlyflows)/sqrt(d)
  #U             =all other rows in Y except last row
  #disags        =disaggregated data  
  #               format:yr1mon1sim1 yr1mon2sim1 yr1mon3sim1 yr1mon4sim1 yr2mon1sim1...
  #                      yr1mon1sim2 yr1mon2sim2 yr1mon3sim2 yr1mon4sim2 yr2mon1sim2...
  #kk            =bandwidth or number of nearest neighbors to use
  #W             =weight function based on bandwidth
  #simset        =a set of simulations, one value per year
  #zsim          =the current simulation value to disaggregate 
  #dist          =distances of hist vals from zsim
  #neighbors     =order of distances of hist vals from zsim (nearest to farthest)
  #rand          =a U(0,1) random number
  #wrank         =rank(c(rand,W))
  #ryear         =a random year from the nearest neighbor years based on weight finction
  #Ystar         =[U,zsim]
  #a,b,c         =placeholders,counters   
  
  indexhist=matrix(0,ncol=1)
  indexhist=apply(histdata,1,sum)
  X=t(histdata)
  #now X contains sites down the rows and years along the columns
  if(back){
    X=t(histdata[1:(length(histdata[,1])-length(years)+1),])
    indexhist=apply(t(X),1,sum)
  }
  
  #open up and call function to calulate rotation matrix as a function of 
  #the dimension d
  source('functions/gs.r')
  R=gs(d)
  R=round(R,6) #so that zeros are represented as zero and not 1.5e-15 or something
  
  Y=R%*%X  #rotate with orthonormal matrix
  U=Y[1:(d-1),]  #all columns and all rows except Y[d,]
  disags=matrix(0,ncol=d*length(years),nrow=nsims)  
  
  kk=round(sqrt(length(years)))
  if(back){
    kk=round(sqrt(length(1949:2005)-length(years)+1))  #number of neighbors
  }
  W = 1:kk  #weight function see regonda et. al. 2005
  W = 1/W
  W = W/sum(W)
  W = cumsum(W)

  #dissagregate flows: for each simulation and year calcualate x*=t(R)Y*
  for(i in 1:nsims){
    simset=matrix(0,ncol=1)
    simset=preds[i,]  #take a vector of simulation values (one prediction each year)
    
    for(j in 1:length(years)){
    
      if(back){
        X=t(histdata[1:(length(histdata[,1])-length(years)+j),])
        Y=R%*%X        #rotate with orthonormal matrix
        U=Y[1:(d-1),]  #all columns and all rows except Y[d,]
        kk=round(sqrt(length(histdata[,1])-length(years)+j))  #number of neighbors
        W = 1:kk       #weight function see regonda et. al. 2005
        W = 1/W
        W = W/sum(W)
        W = cumsum(W)
      }
    
      zsim=simset[j]            #select this particular simulation
      dist=abs(zsim-indexhist)  #find distance between this simulated value and the obs vals
      neighbors=order(dist)     #find nearest neighbors
      neighbors=neighbors[1:kk] #select first kk nearest neighbors
      
      #this next loop resamples the historical data up to maxit 
      #times if any of the disag values are negative
      s=1
      negcheck=1
      while(s<maxit & negcheck>0){  #resample if negative disag
        s=s+1
        negcheck=0
        rand=runif(1,0,1)         #draw single U(0,1) rand num
        wrank=rank(c(rand,W))     #find out which neighbor(year) was selected to resample
        ryear=neighbors[wrank[1]] #isolate year to resample
        
        Ystar=c(U[,ryear],zsim/sqrt(d))  #attach the resampling year
        disagcheck=t(R)%*%Ystar          #transform back to original space
        for(k in 1:d){
          if(disagcheck[k]<0){negcheck=negcheck+1}
        }
      }  
      if(warning & s>=maxit){print('Warning: maximum iterations exceeded, negative value likely')}
      a=(j-1)*d+1 
      b=j*d
      disags[i,a:b]=disagcheck      #put the data in the output array 
    }
  }
  thedisag=disags
}