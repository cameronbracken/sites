predict=function(xcalib,xpred,ycalib,np,nyc,nyp,nsims){
    #this function makes nyp ensemble predictions by bootstrapping 
    #standard error of the local polynomial fit to the calibrated data.
    #Variable list:
    #~inputs~
    #xpred     =a vector of length np with the predictor values at which to 
    #           predict the response variable 
    #xcalib    =a matrix of size=nyc x np which is the predictor data not including the
    #           predictor value to be used in the prediction
    #ycalib    =the response variable vector of lenght nyc for the calibration local fit
    #np        =number of predictors
    #nyc       =number of years in the calibration period
    #nyp       =number of years to predict
    #nsims     =number of simulations
    #~outputs~
    #predict   =is a matrix of ensemble predictions of size=nsims x nyp 

		#Find the alpha for the locfit model-take the alpha with the lowest gcv
		xcalib=as.matrix(xcalib);ycalib=as.matrix(ycalib);xpred=as.matrix(xpred)

		alphas=seq(0.2,1,by=0.05)
		acheck=gcvplot(ycalib~xcalib,alpha=alphas,deg=1,kern="bisq",scale=T)
		gcvvalues=acheck$values
		gcvorder=order(gcvvalues)
		alphamin=alphas[gcvorder[1]]
		
		#Do the single LOCFIT  and get the expected values for each of the calibrated points
		locfitcalib=locfit(ycalib~xcalib,alpha=alphamin,deg=1,kern="bisq",scale=T)
	
		yperturbed=matrix(nrow=nsims,ncol=nyp) # set up the matrix to hold nsims predictions
	
		#Make a new matrix such that first row will be the real predictor
    for(j in 1:nyp){
      xpredcalib=rbind(xpred[j,],xcalib)
      locfitpredicted=predict.locfit(locfitcalib,xpredcalib,se.fit=T,band="global")
      #the year to predict is put back in and predicted 
      
      for(i in 1:nsims){	
        # bootstrap residuals nsims times
        # use standard error of fit to resample residuals
        resids=rnorm(1,0,locfitpredicted$se.fit[1]) #nvals,mean,stdev
        yperturbed[i,j]=locfitpredicted$fit[1]+resids
      }
    }
		predict=yperturbed
}
