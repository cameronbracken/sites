rpssplotfunction=function(indexrpss,preds,years,dropyears,ndropyears,nscores,nsims,title){

  source('functions/myboxplot.r')
  source('functions/myboxplot-stats.r')
  source("functions/RPSS_function.r")
  
  inputfile='inputfiles/disagspaceCMS_index.prn'
  
  d=4
  maxit=100
  warning=F
  
  cisco=matrix(0,nrow=nsims,ncol=nscores*amount)
  grut=matrix(0,nrow=nsims,ncol=nscores*amount)
  bluff=matrix(0,nrow=nsims,ncol=nscores*amount)
  leesferry=matrix(0,nrow=nsims,ncol=nscores*amount)
  
  histdata=matrix(scan(inputfile),ncol=d,byrow=T)
  indexhist=matrix(0,ncol=1)
  indexhist=apply(histdata,1,sum)
  X=t(histdata)
  
  source('functions/gs.r')
  R=gs(d)
  R=round(R,6) #so that zeros are represented as zero and not 1.5e-15 or something
  
  Y=R%*%X  #rotate with orthonormal matrix
  U=Y[1:(d-1),]  #all columns and all rows except Y[d,]
  disags=matrix(0,ncol=d*nscores*ndropyears,nrow=nsims)  
  
  kk=round(sqrt(length(years)))
  if(back){
    kk=round(sqrt(length(1949:2005)-length(years)+1))  #number of neighbors
  }
  W = 1:kk  #weight function see regonda et. al. 2005
  W = 1/W
  W = W/sum(W)
  W = cumsum(W)
  
  #dissagregate flows: for each simulation and year calcualate x*=t(R)Y*
  for(i in 1:nsims){
    print(paste('disaggregating simulation ',i,'/',nsims,sep=''))
    simset=matrix(0,ncol=1)
    simset=preds[i,]  #take a vector of simulation values (one prediction each year)
    
    for(j in 1:(amount*nscores)){
    
      if(back){
        X=t(histdata[1:(length(histdata[,1])-length(years)+j),])
        Y=R%*%X        #rotate with orthonormal matrix
        U=Y[1:(d-1),]  #all columns and all rows except Y[d,]
        kk=round(sqrt(length(histdata[,1])-length(years)+j))  #number of neighbors
        W = 1:kk  #weight function see regonda et. al. 2005
        W = 1/W
        W = W/sum(W)
        W = cumsum(W)
      }
    
      zsim=simset[j]
      dist=abs(zsim-indexhist)  #find distance between this simulated value and the obs vals
      neighbors=order(dist)     #find nearest neighbors
      neighbors=neighbors[1:kk] #select first kk nearest neighbors
      
      s=1
      negcheck=1
      while(s<maxit & negcheck>0){  #resample if negative disag
        s=s+1
        negcheck=0
        rand=runif(1,0,1)         #draw single U(0,1) rand num
        wrank=rank(c(rand,W))     #find out which neighbor(year) was selected to resample
        ryear=neighbors[wrank[1]] #isolate year to resample
        
        Ystar=c(U[,ryear],zsim/sqrt(d))  #attach the resampling year
        disagcheck=t(R)%*%Ystar
        for(k in 1:d){
          if(disagcheck[k]<0){negcheck=negcheck+1}
        }
      }  
      if(warning & s>=maxit){print('Warning: maximum iterations exceeded, negative value likely')}
      a=(j-1)*d+1 
      b=j*d
      cisco[i,j]=disagcheck[1]       #transform back to original space
      grut[i,j]=disagcheck[2]
      bluff[i,j]=disagcheck[3]
      leesferry[i,j]=disagcheck[4]
    }
  }
   
  rpss=matrix(0,ncol=d,nrow=nscores)  
  
  for(k in 1:nscores){
  
    drop=vector(length(years),mode='logical')
    for(i in 1:length(years)){
      for(j in 1:amount){
        if(years[i]==dropyears[k,j]){drop[i]=TRUE}
      }
    }
      
    a=(k-1)*amount+1
    b=k*amount
    
    print(paste('Cisco Simulation ',k,'/',nscores,sep=''))
    rpss[k,1]=RPSS(histdata[drop,1],cisco[,a:b])
    
    print(paste('GRUT Simulation ',k,'/',nscores,sep=''))
    rpss[k,2]=RPSS(histdata[drop,2],grut[,a:b])
    
    print(paste('Bluff Simulation ',k,'/',nscores,sep=''))
    rpss[k,3]=RPSS(histdata[drop,3],bluff[,a:b])
    
    print(paste('Lees Ferry Simulation ',k,'/',nscores,sep=''))
    rpss[k,4]=RPSS(histdata[drop,4],leesferry[,a:b])
  }
  rpss=data.frame(cbind(rpss,indexrpss))
  names(rpss)=c('Cisco','GRUT','Bluff','Lees Ferry','Index')
  quartz()
  myboxplot(rpss,ylab='RPSS',main=paste(title,'Drop 12.3% Validation'),cex=0.3)
  
  rpssplotfunction=rpss
}