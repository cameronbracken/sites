 statplots=function(plt=T,plots=T,tdisag=T,nsims){
    #This function does two main things:
    #1. verifies the disaggregated values have the same statistical properties as the the 
    #   historical record and plots them if plots=T
    #2. does a temporal disaggregation on top of the spatial of the disaggregation of the 
    #   historical data at lees ferry to verify that the KNN resampling preserves the 
    #   distributional shape of the historical data, also plots spaghetti plots for 
    #   each month apr-jul.
    #If plt=F then nothing is done at all.
    #This was written for a seasonal average dissagregated into four sites so it will not 
    #for much else. The four sites are:Cisco, GRUT(greenriver utah), Bluff and lees ferry
    #Variable list:
    #
    #inputs-
    #plt         =if plt=F then dont do anything default is plt=T
    #plots       =if plots=F then do not calculate or display statistics varifcation plots
    #tdisag      =if tdisag=F then do not to the LF temporal disag or plots for checking purposes
    #histdata    =matrix of historical seasonal flow data(1949-2005) for all four sites
    #             years down rows,sites across columns
    #disags      =all of the disagregated predictions in the format prescribed by main program
    #nsims       =number of simulations for each year 
    #
    #local vaiables-
    #cisco...    =these are used in different ways but mostly just hold disaggregated values
    #LF          =disaggregated Lees Ferry flows for further dissagregation
    #means...    =hold statistics for plotting boxplots
    #samplesize  =the size of the random sample to take from the obs data for diagnostics
    #lftimedata  =the monthly flow apr-jul for leesferry used for tempora disag
    #apr,may,... =disaggregated ensemble predictions for apr-jul at lees ferry
    
  if(plt){
        source('functions/myboxplot.r')
        source('functions/myboxplot-stats.r')
        source('functions/skew.r')
        
        inputfile='inputfiles/disagspace_allyearsCMS.prn'
        histdata=matrix(scan(inputfile),ncol=4,byrow=T)
        years=1906:2005
        l=length(years)
        d=4
        sampsize=100
        
        #these arrays hold nsims disaggregated values for each 
        #year in the record years across, sims down
        cisco=matrix(0,nrow=nsims,ncol=1);grut=matrix(0,nrow=nsims,ncol=1)
        bluff=matrix(0,nrow=nsims,ncol=1);leesferry=matrix(0,nrow=nsims,ncol=1)
        LF=matrix(0,nrow=nsims,ncol=sampsize)
        
        #set up statistics arrays which will hold the statistics for each 
        #disagregated simulation for each site
        #these arrays have sites across the columns and
        #simualtions down the rows
        means=matrix(0,nrow=nsims,ncol=d)
        sds=matrix(0,nrow=nsims,ncol=d)
        skews=matrix(0,nrow=nsims,ncol=d)
        maxs=matrix(0,nrow=nsims,ncol=d)
        mins=matrix(0,nrow=nsims,ncol=d)
        lagcor=matrix(0,nrow=nsims,ncol=6)
        
        for(i in 1:nsims){
          #sample 100 values (with replacement) from the historical record of the
          #index site and disaggregate those, then calclate statistics for disaggregagted 
          #monthly data, repeat nsims times
          
          #the only difference from the normal disag is that here the historic
          #data is resampled and disaggregated, the simulation data is not 
          #disaggregated here
          sample=sample(apply(histdata,1,sum),sampsize,replace=T)
          
          disagtest=matrix(0,nrow=sampsize,ncol=d)
          simset=matrix(0,ncol=1)
          simset=sample  #take a vector of simulation nsims values 
          
          indexhist=apply(histdata,1,sum)
          
          X=t(histdata)
          #now X contains sites down the rows and years along the columns

          #open up and call function to calulate roation matrix as a function of 
          #the dimension d
          source('functions/gs.r')
          R=gs(d)
          R=round(R,6) #so that zeros are represented as zero and not 1.5e-15 or something
          
          Y=R%*%X  #rotate with orthonormal matrix
          U=Y[1:(d-1),]  #all columns and all rows except Y[d,]
          
          kk=round(sqrt(length(years)))  #number of neighbors
          W = 1:kk  #weight function
          W = 1/W
          W = W/sum(W)
          W = cumsum(W)

          #this is the actual disaggregation
          for(j in 1:sampsize){
            zsim=simset[j]
            dist=abs(zsim-indexhist)  #find distance between this simulated value and the obs vals
            neighbors=order(dist)     #find nearest neighbors
            neighbors=neighbors[1:kk] #select first kk nearest neighbors
            
            rand=runif(1,0,1)         #draw single U(0,1) rand num
            wrank=rank(c(rand,W))     #find out which neighbor(year) was selected to resample
            ryear=neighbors[wrank[1]] #isolate year to resample
            
            Ystar=c(U[,ryear],zsim/sqrt(d))
            disagtest[j,]=t(R)%*%Ystar
          }
          
          #pull the sites values out of the disagtest array
          cisco=disagtest[,1]
          grut=disagtest[,2]
          bluff=disagtest[,3]
          leesferry=disagtest[,4]
          LF[i,]=disagtest[,4]
                 
          if(plots){
            #these values will be used to make the plots of the statistics 
            #of the disaggregated values
            for(j in 1:d){           
                #calculate the statistics for each simulation
                if(j==1){thesite=cisco}
                if(j==2){thesite=grut}
                if(j==3){thesite=bluff}
                if(j==4){thesite=leesferry}
                
                means[i,j]=mean(thesite)
                sds[i,j]=sd(thesite)    
                skews[i,j]=skew(thesite)  
                maxs[i,j]=max(thesite)   
                mins[i,j]=min(thesite)    
            }
            #this is not the lag correlation but the spatial correlation between sites
            lagcor[i,1]=cor(cisco,grut)
            lagcor[i,2]=cor(cisco,bluff)
            lagcor[i,3]=cor(cisco,leesferry)
            lagcor[i,4]=cor(grut,bluff)
            lagcor[i,5]=cor(grut,leesferry)
            lagcor[i,6]=cor(bluff,leesferry)
          }
    }

      #if tdisag=T then this part will do a temporal diagregation at lees ferry
      #and look at the PDFs to make sure the shape is preserved.
      #once again the disagregation procedure is the same but it just uses
      #the monthly flow data
      if(tdisag){
        lftimedata=matrix(scan('inputfiles/disagtimeCMS_leesall.prn'),ncol=4,byrow=T)
        lftimedata=lftimedata/4  #divide by four because values were seasonal averages
        
        source('functions/thedisag.r')
        disagtime=thedisag(1:sampsize,lftimedata,LF,d)
        
        source('functions/spaghetti.r')
        title='Lees Ferry-Check'
        #plot the disaged hist data at just leesferry befor temporal disag
        spaghetti(plt=T,1:99,LF,histdata[,4],nsims,noodles=50,title)
        
        
        apr=matrix(0,nrow=nsims,ncol=sampsize)
        may=matrix(0,nrow=nsims,ncol=sampsize)
        jun=matrix(0,nrow=nsims,ncol=sampsize)
        jul=matrix(0,nrow=nsims,ncol=sampsize)
    
        for(i in 1:sampsize){
          a=(i-1)*d+1
          apr[,i]=disagtime[,a]
          may[,i]=disagtime[,a+1]
          jun[,i]=disagtime[,a+2]
          jul[,i]=disagtime[,a+3]
        }
        
        spaghetti(plt=T,1:99,apr,lftimedata[,1],nsims,noodles=50,title='Lees Ferry-Apr Check')
        spaghetti(plt=T,1:99,may,lftimedata[,2],nsims,noodles=50,title='Lees Ferry-May Check')
        spaghetti(plt=T,1:99,jun,lftimedata[,3],nsims,noodles=50,title='Lees Ferry-Jun Check')
        spaghetti(plt=T,1:99,jul,lftimedata[,4],nsims,noodles=50,title='Lees Ferry-Jul Check')
      }
                   
      if(plots){                         
        Names=c('Cisco','Green River','Bluff','Lees Ferry')
        means=data.frame(means);sds=data.frame(sds)
        skews=data.frame(skews);mins=data.frame(mins)
        maxs=data.frame(maxs);lagcor=data.frame(lagcor)
        names(means)=Names;names(sds)=Names
        names(skews)=Names;names(mins)=Names
        names(maxs)=Names
        names(lagcor)=c('C-G','C-B','C-LF','G-B','G-LF','B-LF')
        
        #plot each of the statistics in a new quartz window
        quartz()
        myboxplot(means,main='Mean',outline=F)
        lines(apply(histdata,2,mean),col='blue')
        points(apply(histdata,2,mean),col='blue')
        
        quartz()
        myboxplot(sds,main='Standard Deviation',outline=F)
        lines(apply(histdata,2,sd),col='blue')
        points(apply(histdata,2,sd),col='blue')
        
        quartz()
        myboxplot(skews,main='Skew',outline=F)
        lines(apply(histdata,2,skew),col='blue')
        points(apply(histdata,2,skew),col='blue')
        
        quartz()
        myboxplot(mins,main='Minimum',outline=F)
        lines(apply(histdata,2,min),col='blue')
        points(apply(histdata,2,min),col='blue')
        
        quartz()
        myboxplot(maxs,main='Maximum',outline=F)
        lines(apply(histdata,2,max),col='blue')
        points(apply(histdata,2,max),col='blue')
        
        quartz()
        cor=c(cor(histdata[,1],histdata[,2]),
        cor(histdata[,1],histdata[,3]),cor(histdata[,1],histdata[,4]),
        cor(histdata[,2],histdata[,3]),cor(histdata[,2],histdata[,4]),
        cor(histdata[,3],histdata[,4]))
        myboxplot(lagcor,main='Spatial Correlation',outline=F)
        lines(cor,col='blue')
        points(cor,col='blue')
      }
    }
}