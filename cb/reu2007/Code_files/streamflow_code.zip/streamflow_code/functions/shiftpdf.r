aprpdf=sm.density(x[,54])
climpdf=sm.density(flows)

plot(aprpdf$eval.points,aprpdf$estimate,typ='l',
     xlim=c(0,max(climpdf$eval.points)),xlab='flows(cms)',ylab='Density')
lines(climpdf$eval.points,climpdf$estimate,typ='l')
abline(v=flows[54],lty='dashed')