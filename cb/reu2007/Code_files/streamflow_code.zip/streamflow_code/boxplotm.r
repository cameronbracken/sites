  
  rm(list=ls())
  source('functions/myboxplot.r')
  source('functions/myboxplot-stats.r')
  
  x=matrix(scan('outputfiles/novppSims_index.txt'),ncol=length(1949:2005),byrow=T)#apr1
  #x=matrix(scan('febppSims.txt'),ncol=length(1949:2005),byrow=T)
  flows=matrix(scan("inputfiles/formatlab.prn"),ncol=17,byrow=T)#input file
  flows=flows[,1]
  title='November 1 Predictions'
  preddate='nov'
  
  back=F   #use back data only
  crbfc=F  #plot the crbfc forecast if crbfc=T (only applicable for lees predictions)
  wet=F    #take out wet years if wet=T
  dry=F    #take out dry years if dry=T
  violin=F #do a violin plot if violoin=T tick mark labels dont work
  box=T    #do a regular boxplot
  
  rpss=0.95
  
  x=data.frame(x)
  #for nodry or nowet data
  y=1949:2005
  years=y
  if(!back&!wet&!dry){
    plotflows=flows
    x=data.frame(x[1:length(years)])#noraml
  }
  if(back){  #back prediction
    years=1990:2005
    plotflows=flows[(length(flows)-15):length(flows)]
    x=data.frame(x[,42:57])
  }  
  if(wet){  #for wet years
    years=sort(y[order(flows)[1:(length(flows)-6)]])
    plotflows=flows[flows<min(flows[order(flows)[(length(flows)-5):length(flows)]])]
    x=data.frame(x[,1:length(plotflows)])
  }
  if(dry){  #for dry years
    years=sort(y[order(flows)[7:length(flows)]])
    plotflows=flows[flows>max(flows[order(flows)[1:6]])]#dry years
    #x=data.frame(x[,flows<min(flows[order(flows)[(length(flows)-5):length(flows)]])])
    x=data.frame(x[,1:length(plotflows)])
  }
  names(x)=years
  
  
  if(box){myboxplot(x,outline=T,cex=.25,ylim=c(0,min(max(x),median(as.matrix(x))+3000)),main=title,xlab='years',ylab='flow(cms)')}
  if(violin){
    library(vioplot)
    vioplot(x[,1],x[,2],x[,3],x[,4],x[,5],x[,6],x[,7],x[,8],x[,9],
          x[,10],x[,11],x[,12],x[,13],x[,14],x[,15],x[,16],
          x[,17],x[,18],x[,19],x[,20],x[,21],x[,22],x[,23],x[,24],x[,25],
          x[,26],x[,27],x[,28],x[,29],x[,30],x[,31],x[,32],x[,33],
          x[,34],x[,35],x[,36],x[,37],x[,38],x[,39],x[,40],x[,41],
          x[,42],x[,43],x[,44],x[,45],x[,46],x[,47],x[,48],x[,49],
          x[,50],x[,51],
          x[,52],x[,53],x[,54],x[,55],x[,56],x[,57],
          col="yellow",border="black",drawRect=F,ylim=c(0,max(x)))
  }
   
  
  if(crbfc&preddate=='jan'){
    lines(1998:2005,c(772.89,644.08,468.42,843.15,608.94,667.47,831.42,913.39)+226.4843,
          col='blue',xlab='',ylab='',lty='solid')
    points(1998:2005,c(772.89,644.08,468.42,843.15,608.94,667.47,831.42,913.39)+226.4843,col='blue')
    legend(c(2002,2005.5),c(1400,1600),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','solid'),col=c('black','blue'))
  }
  if(crbfc&preddate=='apr'){
    lines(c(1997,1998,2000:2005),c(1288.14,796.72,772.73,679.09,352.11,608.86,468.97,995.13)+226.4843, 
          col='blue',xlab='',ylab='',lty='solid')
    points(c(1997,1998,2000:2005),c(1288.14,796.72,772.73,679.09,352.11,608.86,468.97,995.13)+226.4843,col='blue')
    legend(c(2002,2005.5),c(1400,1600),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','solid'),col=c('black','blue'))
  }
  
  lines(plotflows)
  points(plotflows)
  print(min(.9*max(x),median(as.matrix(x))+3000))
  if(back){text(5,min(.9*max(x),median(as.matrix(x))+3000),labels=paste('RPSS=',rpss))}
  if(!back){text(15,min(.9*max(x),median(as.matrix(x))+3000),labels=paste('RPSS=',rpss))}
  if(back){
    abline(quantile(flows,.33),0,lty='dashed')
    abline(quantile(flows,.5),0,lty='dashed')
    abline(quantile(flows,.66),0,lty='dashed')
  }
  if(!back){
    abline(quantile(plotflows,.33),0,lty='dashed')
    abline(quantile(plotflows,.5),0,lty='dashed')
    abline(quantile(plotflows,.66),0,lty='dashed')
  }
  
  
  