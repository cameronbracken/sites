  #This program was made to dissaggregate simulated seasonal flow into 
  #different spatial locations(spatial) the number of locations is d
  #but it is fairly general and can be used for any spatial/temporal disagregation
  #in an dimension d with a little manipulation
  #
  #Variable list:
  #
  #histdata      =program specific, recorded monthly flows at lees ferry apr-jul
  #indexhist     =historical flow values at the index site(sum of four sites)
  #X             =disag data, years across cols, months down rows
  #years         =years in which predictions were made
  #nsims         =number of rows in ensemble prediction data
  #preds         =predictions of seasonal flow for each year, 
  #               years across cols, sims down rows
  #gs            =(function) calculates Gram Schmidt orthonormal matrix 
  #R             =rotation matrix a.k.a. Gram Schmidt orthonormal matrix
  #Y             =rotated data last row is sum(monthlyflows)/sqrt(d)
  #U             =all other rows in Y except last row
  #disags        =disaggregated data  
  #               format:yr1mon1sim1 yr1mon2sim1 yr1mon3sim1 yr1mon4sim1 yr2mon1sim1...
  #                      yr1mon1sim2 yr1mon2sim2 yr1mon3sim2 yr1mon4sim2 yr2mon1sim2...
  #kk            =bandwidth or number of nearest neighbors to use
  #W             =weight function based on bandwidth
  #simset        =a set of simulations, one value per year
  #zsim          =the current simulation value to disaggregate 
  #dist          =distances of hist vals from zsim
  #neighbors     =order of distances of hist vals from zsim (nearest to farthest)
  #rand          =a U(0,1) random number
  #wrank         =rank(c(rand,W))
  #ryear         =a random year from the nearest neighbor years based on weight finction
  #Ystar         =[U,zsim]
  #a,b,c         =placeholders,counters                
  
  rm(list=ls())
  
  source('functions/myboxplot.r')
  source('functions/myboxplot-stats.r')
    
  outputfile='disag_jan_index.out'
  inputfile='inputfiles/disagspaceCMS_index.prn'  #seasonal flow values for each of the four sites
  datafile='outputfiles/janppsims_index.txt'
  month='jan'
   
  back=T      #use only data from the past years (realistic simulation mode only good for 1990:2005)
  splt=F      #make spaghetti plots of forcasted data using spaghetti function
  stplt=F     #use the statplots function; if stplt=F 'plots=' and 'tdisag=' are ignored
  plots=F     #plot statistics in test mode plots using statplots
  tdisag=T    #do a temporal disag of lees ferry hist data to check using statplots
  evalyes=T   #evaluate skill of disag
  warning=F   #give waning message about negative disag values if warning=T
  temporal=F  #do a temporal disagregation of the lees ferry simulation data
  
  years=1949:2005
  if(back){years=1990:2005}
  nsims=250
  d=4  
  maxit=100
  
  #read in historical monthly flows
  histdata=matrix(scan(inputfile),ncol=d,byrow=T)
  
  preds=matrix(scan(datafile),ncol=length(1949:2005),byrow=T)
  if(back){
    preds=preds[,(length(preds[1,])-length(years)+1):length(preds[1,])]
  }

  source('functions/thedisag.r')
  disags=thedisag(years,histdata,preds,d,back,warning,maxit,nsims)
    
  #calculate what proportion of flow predictions are negative.
  c=0
  for(i in 1:nrow(disags)){
    for(j in 1:ncol(disags)){
      if(disags[i,j]<0){
        c=c+1
      }
    }
  }
  print(paste(round(c/(ncol(disags)*nrow(disags))*100,1),'percent negative values',sep=' '))
  
  l=length(years)
  cisco=matrix(0,nrow=nsims,ncol=l)
  grut=matrix(0,nrow=nsims,ncol=l)
  bluff=matrix(0,nrow=nsims,ncol=l)
  leesferry=matrix(0,nrow=nsims,ncol=l)
  
  #get the disag data for each site in an array of its own 
  for(i in 1:l){
    a=(i-1)*d+1
    cisco[,i]=disags[,a]
    grut[,i]=disags[,a+1]
    bluff[,i]=disags[,a+2]
    leesferry[,i]=disags[,a+3]
  }
  
  #make spagehtti plots of each site (ie. a bunch of pdfs ontop of eachother)
  source('functions/spaghetti.r')
  for(i in 1:d){
    if(i==1){thesite=cisco;title='Cisco'}
    if(i==2){thesite=grut;title='GRUT'}
    if(i==3){thesite=bluff;title='Bluff'}
    if(i==4){thesite=leesferry;title='Lees Ferry'}
    spaghetti(splt,years,thesite,histdata[,i],nsims,noodles=50,title)
  }
  
  #This part of the program verifies the disaggregated 
  #values have the same statistical properties as the the 
  #historical record and plots them if stplt=T
  source('functions/statplots.r')
  statplots(stplt,plots,tdisag,nsims)   
  
  #This Part of the program evaluates the skill of the disaggregated simulations
  source('functions/disagskill.r')
  names=c('Cisco','GRUT','Bluff','Lees Ferry','space')
  if(back){disagskill(evalyes,disags,histdata[42:57,],l,paste('back_',month,sep=''),names)}
  if(!back){disagskill(evalyes,disags,histdata,l,month,names)}
  
  if(temporal){
    lftimedata=matrix(scan('inputfiles/disagtimeCMS_lees.txt'),ncol=4,byrow=T)
     
    #multiply leesferry by four because the prediction was of the seasonal average 
    disagtime=thedisag(years,lftimedata,leesferry*4,d,back,warning,maxit,nsims)
    
    names=c('April','May','June','July','temp')
    if(back){disagskill(evalyes,disagtime,lftimedata[42:57,],l,paste('back_',month,sep=''),names)}
    if(!back){disagskill(evalyes,disagtime,lftimedata,l,month,names)}
    
    apr=matrix(0,nrow=nsims,ncol=l)
    may=matrix(0,nrow=nsims,ncol=l)
    jun=matrix(0,nrow=nsims,ncol=l)
    jul=matrix(0,nrow=nsims,ncol=l)

    for(i in 1:l){
      a=(i-1)*d+1
      apr[,i]=disagtime[,a]
      may[,i]=disagtime[,a+1]
      jun[,i]=disagtime[,a+2]
      jul[,i]=disagtime[,a+3]
    }
  
    for(i in 1:d){
      if(i==1){thesite=apr;title='April'}
      if(i==2){thesite=may;title='May'}
      if(i==3){thesite=jun;title='June'}
      if(i==4){thesite=jul;title='July'}
      spaghetti(splt,years,thesite,histdata[,i],nsims,noodles=50,title)
    }
  
    write(t(disagtime),file=paste('temporal_',outputfile,sep=''),ncol=ncol(disagtime),sep='  ')
    print(paste('output file is: ',paste('temporal_',outputfile,sep=''),sep=''))
  }
  
  #finally write out the disags array to a file 
  write(t(disags),file=outputfile,ncol=ncol(disags),sep="  ")
  print(paste('output file is: ',outputfile,sep=''))
    
    