{
  # This program gives the best combination of predictor subsetsets based on different statistics
  # Reads indices from formatted file 
  # 
  # The correlation indices correlated with previous year season (i.e., Nov-Dec and some times Oct-Dec)
  # Variable List:
  # filename        =output filename
  # rawpredictors   =raw data values of predictors (independent variables)
  # response        =response variable (dependent variable)
  # lps             =object that holds leaps output
  # lps$size        =number of variables in each prediction
  # lps$which       =allsubsets (logical)
  # allsubsets      =all chosen subsets of predictors (logical)
  # nsubsets        =number of subsets chosen by leaps 
  # degs            =degree of fit corresponding to value in alphas and gcvs
  # alphas          =alphas which minimize GCV stat in 1 or 2 deg locfit
  # gcvs            =min gcvs for each subset corresponding to alphas and degs
  # alphas1         =alphas used for 1st degree local polynomial fit
  # alphas2         =alphas used for 2nd degree local polynomial fit
  # predset         =particulat set of predictors determined from leaps
  # deg1gcvs        =all gcvs from one gcvplot call with deg 1
  # deg2gcvs        =all gcvs from one gcvplot call with deg 2
  # length1,length2 =begining and ending of set with n predictors
  # gcvsnpred       =GCV valued with n predictors
  # npredictors     =all subsets with n predictors
  # gcvorderd       =ordered version of gcvnpred
  # gcvsorted       =sorted version of gcvnpred
  # countcombos     =counts number of combinations to keep with same n predictors
  # predvars        =subsets passing threshhold all with same n predictors
  # npredset        =predvars binded to gcv values for outpur file
 
  #rm(list=ls())
  library(leaps) 
  library(locfit)
        
  source("functions/leaps_modified.r")	# modified leaps commands loaded
  source("functions/Combination_filter.r")

	
  #-------edit this part (between dashes) for a specific set of predictors------------
  filename="best_models.txt"                      #output file
  f=matrix(scan("inputfiles/allpredictors.prn"),ncol=21,byrow=T)#input file
  novp=f[,2:6]                               #predictors for Nov1
  janp=f[,2:10]                              #predictors for Jan1 
  febp=cbind(f[,2:14],f[,19])                #predictors for Feb1
  aprp=cbind(f[,2:10],f[,15:21])             #predictors for Apr1 #aprp=f[,2:17] for formatlab.prn
  flows=f[,1]                                #seasonal average flows
  
	rawpredictors=febp
  response=flows                             #The response variable 
  
  drymodel=F
  wetmodel=F
  #-----------------------------------------------------------------------------------
  
  
  if(drymodel){
    dryflows=order(flows)[1:17]
    rawpredictors=rawpredictors[dryflows,]
    response=response[dryflows]
    print(response)
    print(rawpredictors)
  }
  if(wetmodel){
    wetflows=order(flows)[(length(flows)-9):length(flows)]
    rawpredictors=rawpredictors[wetflows,]
    response=response[wetflows]
    print(response)
    print(rawpredictors)
  }
  
  file.remove(filename)                      #delete existing file
  
	lps=leaps(rawpredictors,response,nbest=250,method="Cp",int=F) #,strictly.compatible=F)
    # leaps uses the Cp statistic to compare subsets and chooses a set of the best 
    # subsets of predictors and stores them in lps$which
    # nbest-max number of subsets of each size to choose
    # int=TRUE says use the intersept as a variable
    #	(lps$size-1) represent number of variables in each subset because 
    # it consideres intercept also one of the variables though it is not used in this program

  write("------GCV-Results---------",file=filename,append=TRUE)

  allsubsets=lps$which
  nsubsets=length(allsubsets[,1])   #number of subsets chosen
  degs=vector(nsubsets,mode='numeric')
  alphas=vector(nsubsets,mode='numeric')
  gcvs=vector(nsubsets,mode='numeric')
        
  alpha1=seq(.2,1,by=0.05)  #for 1st deg locfit .2
  alpha2=seq(.3,1,by=0.05)  #for 2nd degree locfit .3
  
  for(i in 1:nsubsets){  
          # this loop determines the smoothing parameter and the 
          # corresponding locfit degree which minimizes the GCV statistic  
          
        predset=rawpredictors[,allsubsets[i,]]     
          #pulls predictors out for particular subset

        deg1gcvs=gcvplot(response~predset,alpha=alpha1,deg=1,kern="bisq",scale=T)
        deg2gcvs=gcvplot(response~predset,alpha=alpha2,deg=2,kern="bisq",scale=T)
          #calculate GCV for all alphas in sequence above 
          #repeat for a deg 1 and 2 local fit
          
        print(paste(round(min(c(deg1gcvs$values,deg2gcvs$values))),' ',i,'/',nsubsets,sep=''))
        
        #determine where the lowest GCV value is and what are the alpha and deg
        if(min(deg2gcvs$values)<min(deg1gcvs$values)){  #min GCV has degree 2 locfit
          degs[i]=2
          hold=order(deg2gcvs$values)
          gcvs[i]=deg2gcvs$values[hold[1]]
          alphas[i]=alpha2[hold[1]] 
          }
        else{                                           #min GCV has deg 1 locfit
          degs[i]=1
          hold=order(deg1gcvs$values)
          gcvs[i]=deg1gcvs$values[hold[1]]
          alphas[i]=alpha1[hold[1]]
        }
  }
  for(i in 1:nsubsets){
        print(paste(as.integer(i),gcvs[i],alphas[i]))
  }
  
  
  ### zz=locfit(y~x, alpha=bestalpha, deg=bestdeg, scale=T,..)
  ### predict.locfit(zz, xnew)
  
  length1=1;n=0
  # this loop discards subsets based on a threshhold:
  # if the # of subsets w/ same # of predictors (n) is less than 15
  # then use all subsests with n predictors 
  # else if # subsets w/ same number of predictors (n) 
  # then take all subsets w/ GCV<lowest GCV of subsets w/ 
  # same n predictors or 15 whichever larger
  for(n in 2:max(lps$size) ){
          length2=length1+length(lps$size[lps$size==n])-1
               #determine start and end of set w/ same # of predictors
          gcvnpred=gcvs[length1:length2]  #luckily leaps already orders subsets by # predictors
          npredictors=allsubsets[(length1:length2),]
     
          gcvorderd=order(gcvnpred)  #order just subsets with same n predictors
          gcvsorted=sort(gcvnpred)   #sort just subsets with same n predictors
          
          #plot(sort(gcvsorted))
          #determine how many subsets to use from set with n predictors
          if((gcvsorted[length(gcvsorted)]/gcvsorted[1]) >1.1 ){
            countcombos=0
            while((gcvsorted[countcombos+1])<=(1.1*gcvsorted[1])){countcombos=countcombos+1}
            if(countcombos<15){countcombos=15}
            if(length(gcvsorted)<15){countcombos=length(gcvsorted)}
            }
          else{
            countcombos=15
            if(length(gcvsorted)<15){countcombos=length(gcvsorted)}
            }
        
          #takes first 'countcombos' subsets from set with same n predictors
          predvars=npredictors[gcvorderd[1:countcombos],]
          npredset=data.frame(cbind(predvars,gcvsorted[1:countcombos]))
          write(t(lps$size[length1]),file=filename,append=TRUE,ncol=1)
          
          write(t(npredset),file=filename,append=TRUE,ncol=(ncol(allsubsets)+1))
          #print(length(lps$size[lps$size==i]))
          length1=length2+1
  }
		
	wholegcvorde=order(gcvs)	# All combinations ordered
  
  # Filters the combinations based on correlation between predictor varibles(multicolinearity)
	combinationskept=combinationfilter(rawpredictors,allsubsets[wholegcvorde,])

	write("----------------------------------------",file=filename,append=TRUE)
	write("Best Combinations that are not correlated among themselves",file=filename,append=TRUE)
	write(t(combinationskept),file=filename,append=TRUE,ncol=length(combinationskept))
	write("----------------------------------------",file=filename,append=TRUE)


  #	selects the position of the combinations that will be kept
	finalsel=wholegcvorde[combinationskept]		
  print(finalsel)
	predvars=allsubsets[finalsel,]
	
	gcvratio=1:length(gcvs[finalsel])
	for(igcv in 1:length(gcvratio))
		gcvratio[igcv]=round((gcvs[finalsel][igcv]/gcvs[finalsel][1]),3)
  
  predset=data.frame(cbind((lps$size[finalsel]),predvars,gcvs[finalsel],degs[finalsel],alphas[finalsel],gcvratio))
  write("Finally selcted Combinations--GCV--",file=filename,append=TRUE)
  write(t(predset),file=filename,append=TRUE,ncol=ncol(predset))


}
