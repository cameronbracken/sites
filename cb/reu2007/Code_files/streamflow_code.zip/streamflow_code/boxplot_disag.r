  #this program does the same thing as 'boxplot.r' but it reads in the 
  #specific format of data that is the output of 'disags.r' 
    
    temporal=T
    
    source('functions/myboxplot.r')
    source('functions/myboxplot-stats.r')
    if(!temporal){
        #monthly flow values for each of the four sites
      inputfile='inputfiles/disagspaceCMS_index.prn'  
      datafile='outputfiles/disagoutput/disag_apr_back_index.out'
      statfile='outputfiles/disagoutput/disagskill_space_back_apr.txt'
    }  
    if(temporal){
      inputfile='inputfiles/disagtimeCMS_lees.txt'
      datafile='outputfiles/disagoutput/temporal_disag_apr_back_index.out'
      statfile='outputfiles/disagoutput/disagskill_temp_back_apr.txt'
    }
    preddate='April'
    
    back=T
    cbrfc=T
    
    years=1949:2005
    if(back){years=1990:2005}
    l=length(years)
    d=4
    nsims=250
    if(temporal){names=c('April','May','June','July')}
    if(!temporal){names=c('Cisco','Grut','Bluff','Lees Ferry')}
    
    histdata=matrix(scan(inputfile),ncol=d,byrow=T)
    disags=matrix(scan(datafile),ncol=d*length(years),byrow=T)
    stats=matrix(scan(statfile,nlines=4),nrow=4,ncol=2,byrow=T)
    print(stats)
    
    cisco=matrix(0,nrow=nsims,ncol=l)
    grut=matrix(0,nrow=nsims,ncol=l)
    bluff=matrix(0,nrow=nsims,ncol=l)
    leesferry=matrix(0,nrow=nsims,ncol=l)
    
    for(i in 1:l){
      a=(i-1)*d+1
      cisco[,i]=disags[,a]
      grut[,i]=disags[,a+1]
      bluff[,i]=disags[,a+2]
      leesferry[,i]=disags[,a+3]
    }
    
    cisco=data.frame(cisco);names(cisco)=years
    grut=data.frame(grut);names(grut)=years
    bluff=data.frame(bluff);names(bluff)=years
    leesferry=data.frame(leesferry);names(leesferry)=years
    
    if(back){  #back prediction
      hd=histdata
      histdata=histdata[(length(histdata[,1])-15):length(histdata[,1]),]
    } 
    
    #-------------------------------------------------------------
    quartz()
    myboxplot(cisco,main=paste(preddate,'1',names[1],'Disaggregation Predictions'),
              outline=T,cex=.25,ylim=c(0,min(max(cisco),median(as.matrix(cisco))+1100)),
              xlab='years',ylab='flow(cms)')
    text(13,min(max(cisco),median(as.matrix(cisco))+1100),labels=paste('RPSS=',round(stats[1,2],2),'  MC=',round(stats[1,1],2)))
    if(back){
      abline(quantile(hd[1:41,1],.33),0,lty='dashed')
      abline(quantile(hd[1:41,1],.5),0,lty='dashed')
      abline(quantile(hd[1:41,1],.66),0,lty='dashed')
    }
    if(!back){
      abline(quantile(histdata[,1],.33),0,lty='dashed')
      abline(quantile(histdata[,1],.5),0,lty='dashed')
      abline(quantile(histdata[,1],.66),0,lty='dashed')
    }
    lines(histdata[,1])
    points(histdata[,1])
    
    if(cbrfc & back & preddate=='April' & temporal){
      cbrfcdata=matrix(scan('inputfiles/CBRFCmonthlyforcast_apr.txt'),ncol=5,byrow=T)
      lines(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue')
      legend(c(2000-1989,2004-1989),c(1200,1400),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    #-------------------------------------------------------------
    quartz()
    myboxplot(grut,main=paste(preddate,'1',names[2],'Disaggregation Predictions')
              ,outline=T,cex=.25,ylim=c(0,min(0.95*max(grut),median(as.matrix(grut))+8000))
              ,xlab='years',ylab='flow(cms)')
    text(13,min(0.8*max(grut),median(as.matrix(grut))+800),labels=paste('RPSS=',round(stats[2,2],2),'  MC=',round(stats[2,1],2)))
    if(back){
      abline(quantile(hd[1:41,2],.33),0,lty='dashed')
      abline(quantile(hd[1:41,2],.5),0,lty='dashed')
      abline(quantile(hd[1:41,2],.66),0,lty='dashed')
    }
    if(!back){
      abline(quantile(histdata[,2],.33),0,lty='dashed')
      abline(quantile(histdata[,2],.5),0,lty='dashed')
      abline(quantile(histdata[,2],.66),0,lty='dashed')
    }
    lines(histdata[,2])
    points(histdata[,2])
    
    if(cbrfc & back & preddate=='April' & temporal){
      lines(cbrfcdata[,1]-1989,cbrfcdata[,3]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,3]+226.4843,col='blue')
      legend(c(2002-1989,2006-1989),c(2200,2600),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    #-------------------------------------------------------------
    quartz()
    myboxplot(bluff,main=paste(preddate,'1',names[3],'Disaggregation Predictions'),
              outline=T,cex=.25,ylim=c(0,min(0.9*max(bluff),median(as.matrix(bluff))+4000)),
              xlab='years',ylab='flow(cms)')
    text(2,min(0.9*max(bluff),median(as.matrix(bluff))+4000),labels=paste('RPSS=',round(stats[3,2],2),'  MC=',round(stats[3,1],2)))
    if(back){
      abline(quantile(hd[1:41,3],.33),0,lty='dashed')
      abline(quantile(hd[1:41,3],.5),0,lty='dashed')
      abline(quantile(hd[1:41,3],.66),0,lty='dashed')
    }
    if(!back){
      abline(quantile(histdata[,3],.33),0,lty='dashed')
      abline(quantile(histdata[,3],.5),0,lty='dashed')
      abline(quantile(histdata[,3],.66),0,lty='dashed')
    }
    lines(histdata[,3])
    points(histdata[,3])
    
    if(cbrfc & back & preddate=='April' & temporal){
      lines(cbrfcdata[,1]-1989,cbrfcdata[,4]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,4]+226.4843,col='blue')
      legend(c(2002-1989,2006-1989),c(2600,3100),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    #-------------------------------------------------------------
    quartz()
    myboxplot(leesferry,main=paste(preddate,'1',names[4],'Disaggregation Predictions'),
              outline=T,cex=.25,ylim=c(0,min(max(leesferry)+100,median(as.matrix(leesferry))+1700)),
              xlab='years',ylab='flow(cms)')
    if(!back){text(13,min(max(leesferry),median(as.matrix(leesferry))+1200),labels=paste('RPSS=',round(stats[4,2],2),'  MC=',round(stats[4,1],2)))}
    if(back){text(4,min(1.05*max(leesferry),median(as.matrix(leesferry))+1200),labels=paste('RPSS=',round(stats[4,2],2),'  MC=',round(stats[4,1],2)))}
    if(back){
      abline(quantile(hd[1:41,4],.33),0,lty='dashed')
      abline(quantile(hd[1:41,4],.5),0,lty='dashed')
      abline(quantile(hd[1:41,4],.66),0,lty='dashed')
    }
    if(!back){
      abline(quantile(histdata[,4],.33),0,lty='dashed')
      abline(quantile(histdata[,4],.5),0,lty='dashed')
      abline(quantile(histdata[,4],.66),0,lty='dashed')
    }
    lines(histdata[,4])
    points(histdata[,4])
    
    if(cbrfc & back & preddate=='January' & !temporal){
      cbrfcdata=matrix(scan('inputfiles/CBRFCforcast_jan.txt'),ncol=2,byrow=T)
      lines(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue')
      legend(c(2002-1989,2006-1989),c(1500,1800),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    if(cbrfc & back & preddate=='April' & !temporal){
      cbrfcdata=matrix(scan('inputfiles/CBRFCforcast_apr.txt'),ncol=2,byrow=T)
      lines(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,2]+226.4843,col='blue')
      legend(c(2002-1989,2006-1989),c(1700,2000),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    if(cbrfc & back & preddate=='April' & temporal){
      lines(cbrfcdata[,1]-1989,cbrfcdata[,5]+226.4843,col='blue',lty='dotdash')
      points(cbrfcdata[,1]-1989,cbrfcdata[,5]+226.4843,col='blue')
      legend(c(2000-1989,2004-1989),c(1700,2000),c('Historical Flow','CBRFC forecast'),
           lty=c('solid','dotdash'),col=c('black','blue'))
    }
    