flows=zeros(100,12);
for i=1:100
    for j=1:12
        flows(i,j)=I((i-1)*12+j);
    end
end
plot(mean(flows,1),'ko-')
xlabel('Months')
ylabel('')

