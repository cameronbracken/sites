for i=1:100
   cdc(i,2:13)=seasonal_flows(i,2); 
end
cdc(:,1)=seasonal_flows(:,1)