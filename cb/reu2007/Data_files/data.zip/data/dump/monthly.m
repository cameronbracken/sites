month=zeros(100,12);
for i=1:100;
    month(i,:)=mon((i-1)*12+1:i*12,3);
end
month